from django.db import models

# Create your models here.
class Emp(models.Model):
    eno = models.IntegerField(primary_key=True)
    ename = models.CharField(max_length=20)
    esal = models.FloatField()
    eaddress = models.CharField(max_length=50)