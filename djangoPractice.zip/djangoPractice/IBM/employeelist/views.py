from django.shortcuts import render


from .models import Emp
# Create your views here.

def showemp(r):
    emp_list = Emp.objects.all() #ORM Query
    my_dict = {'emp_list':emp_list}
    return render(r,'employeelist/Employeelist.html',context=my_dict)

