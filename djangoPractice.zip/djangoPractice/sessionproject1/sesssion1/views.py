from django.shortcuts import render

# Create your views here.
def get_name(request):
    return render(request,'session1/name.html')

def get_income(request):
    name = request.GET['name']
    response = render(request,'session1/income.html',{'name':name})
    response.set_cookie('name',name)
    return response

def get_bonus(request):
    income = request.GET['income']
    name = request.COOKIES['name']
    response = render(request,'session1/bonus.html',{'name':name,'income':income})

    response.set_cookie('income',income)
    return response

def get_result(request):
    bonus = request.GET['bonus']
    income = request.COOKIES['income']
    name = request.COOKIES['name']

    response = render(request,'session1/result.html',{'name':name,'income':income,'bonus':bonus})

    response.set_cookie('bonus',bonus)
    return response