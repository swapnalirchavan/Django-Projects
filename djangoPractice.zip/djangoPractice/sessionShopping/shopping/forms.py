from django import forms
class AdditemForm(forms.Form):
    name=forms.CharField()
    quantity=forms.IntegerField()
