from django.shortcuts import render
from shopping.forms import *
# Create your views here.
def add_item_view(request):
    form=AdditemForm()
    if request.method=='POST':
        name=request.POST['name']
        quantity=request.POST['quantity']
        request.session[name]=quantity
    return render(request,'shopping/additem.html',{'form':form})
def display_items_view(request):
    return render(request,'shopping/displayitems.html')
