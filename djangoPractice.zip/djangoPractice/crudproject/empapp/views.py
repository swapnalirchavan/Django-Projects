from django.shortcuts import render, redirect
from .models import Employee
from .forms import EmployeeForm


# Create your views here.
def show(request):
    emp=Employee.objects.all()
    return render(request,'empapp/index.html',{'emp':emp})
def insert(request):
    form=EmployeeForm()
    if request.method=='POST':
        form=EmployeeForm(request.POST)
        if form.is_valid():
            form.save()
        return redirect('/')
    return render(request,'empapp/insert.html',{'form':form})
def delete_view(request,eno):
    employee=Employee.objects.get(eno=eno)
    employee.delete()
    return redirect('/')
def update_view(request,eno):
    employee=Employee.objects.get(eno=eno)
    if request.method=='POST':
        form=EmployeeForm(request.POST,instance=employee)
        if form.is_valid():
            form.save()
            return redirect('/')
    return render(request,'empapp/update.html',{'employee':employee})


