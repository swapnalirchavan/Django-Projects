from django.shortcuts import render
from .import forms
from testapp.models import Student
# Create your views here.
def student_form_view(request):
    form= forms.StudentForm()
    if request.method=='POST':
        form=forms.StudentForm(request.POST)
        if form.is_valid():
            form.save(commit=True)
    return render(request,'testapp/studentform.html',{'form':form})
def student_view(request):
    stud_list=Student.objects.all()
    return render(request,'testapp/student.html',{'stud_list':stud_list})