import datetime

from django.shortcuts import render

# Create your views here.
def results(request):
    dt=datetime.datetime.now()
    name="Durga"
    rollno=101
    marks=100
    mydict={'date': dt, 'name':name, 'rollno':rollno, 'marks': marks}
    return render(request,'testapp/results.html',context=mydict)