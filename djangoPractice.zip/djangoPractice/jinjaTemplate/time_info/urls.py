from django.contrib import admin
from django.urls import path
from time_info import views

urlpatterns = [
       path('time/',views.show),
]