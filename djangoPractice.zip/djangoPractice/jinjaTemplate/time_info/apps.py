from django.apps import AppConfig


class TimeInfoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'time_info'
