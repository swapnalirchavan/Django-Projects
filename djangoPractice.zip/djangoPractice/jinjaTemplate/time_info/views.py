from django.shortcuts import render
import datetime
# Create your views here.
def show(request):
    date=datetime.datetime.now()
    my_dict={'date':date}
    return render(request,'time_info/show.html',context=my_dict)