from django.db import models

# Create your models here.
class Laptop(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=30)
    price = models.FloatField(default=0)
    color = models.CharField(max_length=20)
    brand = models.CharField(max_length=20)

class Mobiles(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=30)
    price = models.FloatField()
    color = models.CharField(max_length=20)
    brand = models.CharField(max_length=20)

