from django import forms
from .models import Laptop,Mobiles

class LaptopForm(forms.ModelForm):
    class Meta:
        model = Laptop
        exclude =('color',)

class MobileForm(forms.ModelForm):
    class Meta:
        model = Mobiles
        fields = "__all__"