from django.shortcuts import render
from .forms import LaptopForm,MobileForm
from .models import Laptop
# Create your views here.

def thanks(r):
    lap = Laptop.objects.all()
    return render(r,'products/thanks.html',{'lap':lap})


def LaptopView(r):
    LapForm = LaptopForm()
    if r.method=='POST':
        print(r.POST)
        LapForm = LaptopForm(r.POST)
        if LapForm.is_valid():
            LapForm.save(commit=True)
            return thanks(r)
    return render(r,'products/laptops.html',{'LapForm':LapForm})


