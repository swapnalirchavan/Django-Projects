from django.contrib import admin
from .models import Laptop,Mobiles
# Register your models here.
class LaptopAdmin(admin.ModelAdmin):
    list_display = ['id','name','price','color','brand']
class MobileAdmin(admin.ModelAdmin):
    list_display = ['id','name','price','color','brand']

admin.site.register(Laptop,LaptopAdmin)
admin.site.register(Mobiles,MobileAdmin)