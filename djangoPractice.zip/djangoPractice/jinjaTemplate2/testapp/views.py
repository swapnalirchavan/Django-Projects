from django.shortcuts import render
import datetime

# Create your views here.
def wish(request):
    date=datetime.datetime.now()
    msg="hello guest!!!! very good"
    h=int(date.strftime('%H'))
    if h<12:
        msg+='morning!!!'
    elif h<16:
        msg+='Afternoon!!!'
    elif h<21:
        msg+='Evening!!!'
    else:
        msg="Hello guest!!! very very good night!!!"
    mydict={'insert_date':date, 'insert_msg':msg}
    return render(request,'testapp/wish.html', context=mydict)
