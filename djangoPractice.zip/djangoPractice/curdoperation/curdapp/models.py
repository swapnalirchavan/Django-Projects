# import win32timezone
from django.db import models

# Create your models here.

class Employee(models.Model):
    eno=models.IntegerField()
    ename = models.CharField(max_length=35)
    esal=models.IntegerField()
    eadd=models.TextField()
    edate = models.DateField(auto_now_add=True)
    edatetime = models.DateTimeField(auto_now_add=True)

