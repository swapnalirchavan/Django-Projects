from django.shortcuts import render
from .import forms

# Create your views here.
def feedbackview(request):
    sent=False

    if request.method=='POST':
        form=forms.FeedBackForm(request.POST)
        if form.is_valid():
            print("form validation success and printing information")
            print("name:",form.cleaned_data['name'])
            print("roll no:",form.cleaned_data['rollno'])
            print("Email:", form.cleaned_data['email'])
            print("Feedback:", form.cleaned_data['feedback'])
            sent=True
    form=forms.FeedBackForm()
    return render(request,'testapp/feedback.html',{'form':form,'sent':sent})
