from django.contrib import admin
from .models import Employee1
# Register your models here.
class EmployeeAdmin1(admin.ModelAdmin):
    list_display = ['eno','ename','esal','eaddr']
admin.site.register(Employee1,EmployeeAdmin1)

