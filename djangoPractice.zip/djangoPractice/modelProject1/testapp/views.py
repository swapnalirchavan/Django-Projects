from django.shortcuts import render
from testapp.models import Employee1
# Create your views here.
def empdata(request):
    emplist=Employee1.objects.all()
    mydict={'emplist':emplist}
    return render(request,'testapp/emp.html',context=mydict)

