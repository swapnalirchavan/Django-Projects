from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .forms import SignupForm
from django.http import HttpResponseRedirect
# Create your views here.
def home(request):
    return render(request,'authapp/home.html')
@login_required
def feedback(request):
    return render(request,'authapp/feedback.html')

def result(request):
    return render(request,'authapp/result.html')

def logout(request):
    return render(request,'authapp/logout.html')


def signup(request):
    form = SignupForm()
    if request.method=='POST':
        form =SignupForm(request.POST)
        user = form.save()
        user.set_password(user.password).save()

        return HttpResponseRedirect('/accounts/login')



    return render(request,'authapp/signup.html',{'form':form})