from django.shortcuts import render
from . import forms

# Create your views here.
def studview(request):
    form=forms.studentForm()
    return render(request,'testapp/input.html',{'form':form})
'''
alternative way:
def studview(request):
    form=forms.studentForm()
    return render(request,'testapp/input.html',{'form':form})
'''

