from django.shortcuts import render
import datetime
# Create your views here.
def wish(request):
    date=datetime.datetime.now()
    msg=None
    h=int(date.strftime('%H'))
    if h<12:
        msg="Good morning"
    elif h<21:
        msg="Good Evening"
    else:
        msg="Good night"
    mydict={'insert_date':date,'insert_msg':msg}
    return render(request,"statapp/wish.html",context=mydict)