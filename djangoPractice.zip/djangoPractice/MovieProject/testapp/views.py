from django.shortcuts import render
from testapp.models import movie
from testapp.forms import movieForm

# Create your views here.
def index_view(request):
    return render(request,'testapp/index.html')
def add_movie_view(request):
    form=movieForm()
    if request.method=='POST':
        form=movieForm(request.POST)
        if form.is_valid():
            form.save()
        return index_view(request)
    return render(request,'testapp/addmovie.html',{'form':form})
def list_movie_view(request):
    movie_list=movie.objects.all().order_by('-rating')
    return render(request,'testapp/listmovie.html',{'movie_list':movie_list})