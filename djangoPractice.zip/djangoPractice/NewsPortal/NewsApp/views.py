from django.shortcuts import render

# Create your views here.
def movies(request):
    mydict={
        'head_msg':'movies information',
        'msg1':'sonali slowely getting cured',
        'msg2':'Bahubali3 is just planning',
        'msg3':'salman khan ready to marriage',
        'photo':'images/python.png'
    }
    return render(request,'NewsApp/news.html',{'mydict':mydict})
def sportsinfo(request):
    mydict = {
        'head_msg': 'movies information',
        'msg1': 'anushka sharma firing like anything',
        'msg2': 'kohli updating in game like anything',
        'msg3': 'worst performance by india sehwag'
    }
    return render(request,'NewsApp/news.html',context=mydict)
def politicsinfo(request):
    mydict = {
        'head_msg': 'movies information',
        'msg1': 'anushka sharma firing like anything',
        'msg2': 'kohli updating in game like anything',
        'msg3': 'worst performance by india sehwag'
    }
    return render(request,'NewsApp/news.html',context=mydict)

def index(request):
    return render(request,'NewsApp/index.html')



