from django.shortcuts import render
from testapp.forms import studentForm

# Create your views here.
def studview(request):
    form=studentForm()
    sent=False
    if request.method=='POST':
        form=studentForm(request.POST)
        if form.is_valid():
            print('form validation success and printing data')
            print('Name:',form.cleaned_data['name'])
            print('Marks:',form.cleaned_data['marks'])
            sent=True
    form=studentForm()
    return render(request,'testapp/input.html',{'form':form,'sent':sent})
