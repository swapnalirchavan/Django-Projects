from django.shortcuts import render
from .import forms

# Create your views here.
def feedbackview(request):
    form=forms.FeedbackForm()
    mydict={'form':form}
    if request.method=='POST':
        form=forms.FeedbackForm(request.POST)
        if form.is_valid():
            print("form validation succeeded!!!!")
            print("name",form.cleaned_data['name'])
            print("rollno",form.cleaned_data['rollno'])
            print("email",form.cleaned_data['email'])
            print("feedback",form.cleaned_data['feedback'])
    return render(request,'testapp/feedback.html',context=mydict)
