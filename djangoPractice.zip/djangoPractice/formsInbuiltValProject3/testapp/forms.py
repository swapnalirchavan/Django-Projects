from django import forms
from django.core import validators
def starts_with_d(value):
    if value[0].lower()!='d':
        raise forms.ValidationError('name should start with d|D')

class FeedbackForm(forms.Form):
    name=forms.CharField(validators=[starts_with_d])
    rollno=forms.IntegerField()
    email=forms.EmailField()
    feedback=forms.CharField(widget=forms.Textarea,validators=[validators.MaxLengthValidator(4)])


